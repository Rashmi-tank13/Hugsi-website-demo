import * as React from 'react';

const Articles=()=> {

    const img1=require('../images/article1.png');
    const img2=require('../images/article2.png');

  return (
      <>

      <div>
      <h2 className='article-h2'>Latest Articles</h2>
      </div>

<div class="w3-row-padding w3-margin-top" style={{width:'100%',margin:'auto'}}>
    <div class="w3-third">
      <div class="w3-card" style={{width:"100%" ,borderRadius: "5px", border: "0.1px solid #99c93c"}}>
        <img src={img1} style={{width:"100%" ,height:"20rem", textTransform: "none",backgroundSize: "cover",objectFit:'contain'}}/>
        <div class="w3-container" style={{backgroundColor: 'black',opacity: "0.6", color: 'white',textAlign: 'center'}}>
          <h5 style={{fontSize:'1.5rem',fontWeight:'bold'}}>The Green KPI's HUGSI</h5>
        </div>
      </div>
    </div>
  
    <div class="w3-third">
      <div class="w3-card" style={{width:"100%" ,borderRadius: "5px", border: "0.1px solid #99c93c"}} >
        <img src={img2} style={{width:"100%",height:"20rem",textTransform: "none",objectFit:'contain'}}/>
        <div class="w3-container" style={{backgroundColor: 'black',opacity: "0.6", color: 'white',textAlign: 'center'}}> 
          <h5 style={{fontSize:'1.5rem',fontWeight:'bold'}}>Is the world getting greener?</h5>
        </div>
      </div>
    </div>
  
    <div class="w3-third">
      <div class="w3-card" style={{width:"100%" ,borderRadius: "5px", border: "0.1px solid #99c93c"}}>
        <img src={img1} style={{width:"100%",height:"20rem",textTransform: "none",backgroundSize: "cover",objectFit:'contain'}}/>
        <div class="w3-container" style={{backgroundColor: 'black',opacity: "0.6", color: 'white',textAlign: 'center'}}>
          <h5 style={{fontSize:'1.5rem',fontWeight:'bold'}}>The Green KPI's HUGSI</h5>
        </div>
      </div>
    </div>
  </div>
  <button className='articles-button'>See all articles</button>
      </>
    
  );
}

export default Articles
