import * as React from 'react';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import ButtonBase from '@mui/material/ButtonBase';



export default function About() {

  const about = require('../images/about.png');
  const labellogo = require('../images/about-label.png')

  return (
<>
<hr/>
    <Grid container spacing={3} sx={{marginTop:'3.5rem',marginLeft:'0.5rem'}}>
      <Grid item >
        <ButtonBase sx={{ width: 128, height: 128 }}>
          <img alt="complex" src={about} />
        </ButtonBase>
      </Grid>
      <Grid item xs={10} sm container>
        <Grid item xs container direction="column" spacing={2}>
          <Grid item xs>
            <Typography gutterBottom variant="subtitle1" component="div" sx={{
              fontWeight: '900',
              fontSize: '2.3rem',
              lineHeight: '1.75',
              letterSpacing: '0.00938em',
              marginBottom: '1.5rem',
              marginTop: '-3.2rem',
              marginLeft: '2rem'
            }}>
              What do you know about sustainable green space?
            </Typography>
            <Typography variant="body2" gutterBottom sx={{fontSize:'1rem',fontWeight:'400',lineHeight:'1.5',marginLeft:'2rem',width:'100%'}}>
              Together with our partner NL Greenlabel we have put together an educational quiz where you can test your skills and learn new things about how you can have a more sustainable approach to green space
            </Typography>

          </Grid>
          <Grid item>
            <Typography sx={{fontSize:'1.3rem', fontWeight:'bold',marginLeft:'2rem',marginTop:'2rem',color:'rgb(105,141,41)' }} variant="body2">
              Take the quiz<i className="fas fa-arrow-right" aria-hidden="false"  style={{marginLeft:'0.8rem',fontWeight:'600'}} />
            </Typography>
          </Grid>
        </Grid>
        
      </Grid>
      <Grid item xs={1.8}>
        <ButtonBase>
          <img alt="complex" src={labellogo} style={{marginTop:'2.3rem'}}/>
        </ButtonBase>
      </Grid>
    </Grid>
    <hr/>
    </>
  );
}