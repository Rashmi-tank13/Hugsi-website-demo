import * as React from 'react';





const Categories = () => {
    const percentage = require('../images/percentage.png');
    const smile = require('../images/smile.png');
    const distribution = require('../images/distribution.png');
    const user = require('../images/user.png');
    const tree = require('../images/tree.png');
    const grass = require('../images/grass.png');
    return (
        <>

            <div className="w3-container" >
                <h2 className='article-h2'>Categories</h2>
            </div>

            <div className="w3-row">
                <div className="w3-col m4  w3-center" style={{ display: 'flex' }}>
                    <div className='category-img' style={{ width: '120px' }}>
                        <img src={percentage} className='categories-img'></img>
                    </div>
                    <div className='category-content'>
                        <div className='category-title' style={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ color: '#868686', fontSize: '1.25em', maxWidth: '255px', textAlign: 'left' }}>Highest percentage of urban green space</span>
                            <div style={{ height: '1rem', width: "1rem", backgroundColor: "rgb(153, 201, 60)", borderRadius: '0.5rem', display: 'flex', placeContent: 'center', placeItems: 'center' }}>
                                <i class="fas fa-question" style={{ color: "rgb(255, 255, 255)", fontWeight: "bold", fontSize: "0.5rem" }}></i>
                            </div>
                        </div>
                        <h5 className='categories-title'>Utrechtse Heuvelrug Municipality</h5>
                    </div>
                </div>
                <div className="w3-col m4  w3-center" style={{ display: 'flex' }}>
                <div className='category-img' style={{ width: '120px' }}>
                        <img src={smile} className='categories-img'></img>
                    </div>
                    <div className='category-content'>
                        <div className='category-title' style={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ color: '#868686', fontSize: '1.25em', maxWidth: '255px', textAlign: 'left' }}>Best health of urban vegetation</span>
                            <div style={{ height: '1rem', width: "1rem", backgroundColor: "rgb(153, 201, 60)", borderRadius: '0.5rem', display: 'flex', placeContent: 'center', placeItems: 'center' }}>
                                <i class="fas fa-question" style={{ color: "rgb(255, 255, 255)", fontWeight: "bold", fontSize: "0.5rem" }}></i>
                            </div>
                        </div>
                        <h5 className='categories-title'>Oudewater Municipality</h5>
                    </div>
                </div>
                <div className="w3-col m4  w3-center" style={{ display: 'flex' }}>
                <div className='category-img' style={{ width: '120px' }}>
                        <img src={distribution} className='categories-img'></img>
                    </div>
                    <div className='category-content'>
                        <div className='category-title' style={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ color: '#868686', fontSize: '1.25em', maxWidth: '255px', textAlign: 'left' }}>Best distribution of urban green space</span>
                            <div style={{ height: '1rem', width: "1rem", backgroundColor: "rgb(153, 201, 60)", borderRadius: '0.5rem', display: 'flex', placeContent: 'center', placeItems: 'center' }}>
                                <i class="fas fa-question" style={{ color: "rgb(255, 255, 255)", fontWeight: "bold", fontSize: "0.5rem" }}></i>
                            </div>
                        </div>
                        <h5 className='categories-title'>Lopik Municipality</h5>
                    </div>
                </div>
            </div>
            <div className="w3-row" style={{ marginTop:'6.5rem',marginBottom:'7rem' }}>
                <div className="w3-col m4  w3-center" style={{ display: 'flex' }}>
                    <div className='category-img' style={{ width: '120px' }}>
                        <img src={user} className='categories-img'></img>
                    </div>
                    <div className='category-content'>
                        <div className='category-title' style={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ color: '#868686', fontSize: '1.25em', maxWidth: '255px', textAlign: 'left' }}>Most urban green space per capital</span>
                            <div style={{ height: '1rem', width: "1rem", backgroundColor: "rgb(153, 201, 60)", borderRadius: '0.5rem', display: 'flex', placeContent: 'center', placeItems: 'center' }}>
                                <i class="fas fa-question" style={{ color: "rgb(255, 255, 255)", fontWeight: "bold", fontSize: "0.5rem" }}></i>
                            </div>
                        </div>
                        <h5 className='categories-title'>Lopik Municipality</h5>
                    </div>
                </div>
                <div className="w3-col m4  w3-center" style={{ display: 'flex' }}>
                <div className='category-img' style={{ width: '120px' }}>
                        <img src={tree} className='categories-img'></img>
                    </div>
                    <div className='category-content'>
                        <div className='category-title' style={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ color: '#868686', fontSize: '1.25em', maxWidth: '255px', textAlign: 'left' }}>Highest percentage of urban area covered by trees</span>
                            <div style={{ height: '1rem', width: "1rem", backgroundColor: "rgb(153, 201, 60)", borderRadius: '0.5rem', display: 'flex', placeContent: 'center', placeItems: 'center' }}>
                                <i class="fas fa-question" style={{ color: "rgb(255, 255, 255)", fontWeight: "bold", fontSize: "0.5rem" }}></i>
                            </div>
                        </div>
                        <h5 className='categories-title'>Laren Municipality</h5>
                    </div>
                </div>
                <div className="w3-col m4  w3-center" style={{ display: 'flex' }}>
                <div className='category-img' style={{ width: '120px' }}>
                        <img src={grass} className='categories-img'></img>
                    </div>
                    <div className='category-content'>
                        <div className='category-title' style={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ color: '#868686', fontSize: '1.25em', maxWidth: '255px', textAlign: 'left' }}>Highest percentage of urban area covered by grass</span>
                            <div style={{ height: '1rem', width: "1rem", backgroundColor: "rgb(153, 201, 60)", borderRadius: '0.5rem', display: 'flex', placeContent: 'center', placeItems: 'center' }}>
                                <i class="fas fa-question" style={{ color: "rgb(255, 255, 255)", fontWeight: "bold", fontSize: "0.5rem" }}></i>
                            </div>
                        </div>
                        <h5 className='categories-title'>Montfoort Municipality</h5>
                    </div>
                </div>
            </div>


        </>
    );
}
export default Categories